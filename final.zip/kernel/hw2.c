#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/capability.h>

asmlinkage long sys_hello(void) { 
	printk("Hello, World!\n");
	return 0;
}


asmlinkage long sys_set_ban(int ban_getpid, int ban_pipe, int ban_kill, int ban_sig) {
    char new_bans = 0;

    if (ban_getpid < 0 || ban_pipe < 0 || ban_kill < 0 || ban_sig < 0) {
        return -EINVAL;
    }

    if (!capable(CAP_SYS_ADMIN)) {
        return -EPERM;
    }

    ban_getpid = (ban_getpid >= 1) ? 1 : 0;
    ban_pipe   = (ban_pipe >= 1) ? 1 : 0;
    ban_kill   = (ban_kill >= 1) ? 1 : 0;
    ban_sig    = (ban_sig >= 1) ? 1 : 0;

    // Bit 0: getpid
    // Bit 1: pipe
    // Bit 2: kill
    // Bit 3: signal
    if (ban_getpid) new_bans |= 1;        // Set bit 0 (00000001)
    if (ban_pipe)   new_bans |= (1 << 1); // Set bit 1 (00000010)
    if (ban_kill)   new_bans |= (1 << 2); // Set bit 2 (00000100)
    if (ban_sig)    new_bans |= (1 << 3); // Set bit 3 (00001000)

    current->syscall_bans = new_bans;

    return 0;
}

asmlinkage long sys_get_ban(char ban) {
   
    if (ban != 'g' && ban != 'p' && ban != 'k' && ban != 's') {
        return -EINVAL;
    }

    switch (ban) {
        case 'g': // getpid is mapped to bit 0
            return (current->syscall_bans & 1) ? 1 : 0;
            
        case 'p': // pipe is mapped to bit 1
            return (current->syscall_bans & (1 << 1)) ? 1 : 0;
            
        case 'k': // kill is mapped to bit 2
            return (current->syscall_bans & (1 << 2)) ? 1 : 0;
            
        case 's': // signal is mapped to bit 3
            return (current->syscall_bans & (1 << 3)) ? 1 : 0;
            
        default:
            return -EINVAL; // Fallback, though the first check prevents reaching here
    }
}

asmlinkage long sys_check_ban(pid_t pid, char ban) {
    struct pid *pid_struct;
    struct task_struct *target_task;
    int target_banned = 0;
    int caller_banned = 0;
    int bit_mask = 0;

    switch (ban) {
        case 'g': bit_mask = 1; break;        // Bit 0
        case 'p': bit_mask = (1 << 1); break; // Bit 1
        case 'k': bit_mask = (1 << 2); break; // Bit 2
        case 's': bit_mask = (1 << 3); break; // Bit 3
        default: return -EINVAL;              // Invalid ban character
    }

    rcu_read_lock(); 
    
    pid_struct = find_vpid(pid);
    if (!pid_struct) {
        rcu_read_unlock();
        return -ESRCH;
    }
    
    target_task = pid_task(pid_struct, PIDTYPE_PID);
    if (!target_task) {
        rcu_read_unlock();
        return -ESRCH;
    }

    target_banned = (target_task->syscall_bans & bit_mask) ? 1 : 0;
    
    rcu_read_unlock(); 

    caller_banned = (current->syscall_bans & bit_mask) ? 1 : 0;
    if (caller_banned) {
        return -EPERM;
    }

    return target_banned;
}

asmlinkage long sys_flip_ban_branch(int height, char ban) {
    int bit_mask = 0;
    int count = 0;
    int i;
    struct task_struct *parent_task;

    if (height <= 0) {
        return -EINVAL;
    }

    switch (ban) {
        case 'g': bit_mask = 1; break;        // Bit 0
        case 'p': bit_mask = (1 << 1); break; // Bit 1
        case 'k': bit_mask = (1 << 2); break; // Bit 2
        case 's': bit_mask = (1 << 3); break; // Bit 3
        default: return -EINVAL;              // Invalid ban character
    }

    if (current->syscall_bans & bit_mask) {
        return -EPERM;
    }

    parent_task = current->real_parent;
    
    for (i = 0; i < height; i++) {
        if (parent_task->pid == 0) {
            break;
        }

        if (parent_task->syscall_bans & bit_mask) {
            parent_task->syscall_bans &= ~bit_mask;
        } else {
            parent_task->syscall_bans |= bit_mask;
            
            count++;
        }

        parent_task = parent_task->real_parent;
    }

    return count;
}